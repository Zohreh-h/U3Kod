package Model;

public class PerUnitItem extends MenuItem {
    private double unitPrice;

    public PerUnitItem(String name, double unitPrice){
        super(name);
        this.unitPrice=unitPrice;
    }
    public double getUnitPrice(){
        return unitPrice;
    }

    @Override
    public String toString(){
        return unitPrice+ super.getName()+ super.getPrice();
    }

}
