package Model;

import java.awt.*;
import java.util.ArrayList;

public class Order {
    private ArrayList<MenuItem> menuItems;
    private int id;
    private double cost;

    public Order(ArrayList<MenuItem> menuItems, int id){
        this.menuItems= menuItems;
        this.id=id;
    }

}

