package Model;

public enum Filling {
    GRÄDDE("grädde", 20),
    GLASS("glass", 30),
    CHOCKLAD("chocklad", 10),
    VANILJ("vanilj", 15),
    FRUKT("frukt", 5);

    private final String fillingName;
    private final double fillingPrice;

    Filling(String name, double fillingPrice){
        this.fillingName=name;
        this.fillingPrice=fillingPrice;

    }
    public String getFillingName(){
        return fillingName;
    }
    public double getFillingPrice(){
        return fillingPrice;
    }
}
