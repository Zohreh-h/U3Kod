package Model;

public class Cake extends MenuItem{


    private Filling[] fillings;
    private double basePrice=100;
    private int sizeInSlices;
    private double totalPrice;

    public Cake( String name, Filling[] fillings, int sizeInSlices){
        super(name);
        this.sizeInSlices= sizeInSlices;
        this. fillings=fillings;
        this.totalPrice =calculatePrice();
    }


    @Override
    public String toString() {
        String fillingsString="";
        for(int i=0; i<fillings.length; i++){
           fillingsString += " " + fillings[i].toString();

        }
        return "Name: "+ super.getName()+ "   fylling: "+ fillingsString +"   Size: "+ sizeInSlices + "   cost: "+ calculatePrice();
    }

    public double calculatePrice(){
        double fillingsPrice=0;
        for(int i=0; i<fillings.length; i++){
            fillingsPrice += fillings[i].getFillingPrice();

        }
        return (basePrice*sizeInSlices)+ fillingsPrice;
    }
    public double getTotalPrice(){
        return totalPrice;
    }
}
