package Model;

public abstract class MenuItem {
    private String name;
    private double price;

    public MenuItem(String name) {
        this.name=name;
        this.price = 100;
    }

    public String getName() {
        return name;
    }
    public double getPrice(){
        return price;
    }


}
