package Model;
/**
 * Holds the different types of flillings with their display name and price
 *
 * */
public enum Filling {
    GRÄDDE("Grädde",20),
GLASS("Glass",30),
CHOCKLAD("Chocklad",10),
VANILJ("Vanilj",15),
FRUKT("Frukt",5);



private final String fillingName;
private  final double fillingPrice;
    /**
     * @param name as a string and fillingPrice as a double
     * @author Miyake,Zohra
     * */
Filling(String name, double fillingPrice){
    this.fillingName = name;
    this.fillingPrice = fillingPrice;
}

    /**
     * @return double of filling price
     * @author Miyake,Zohra
     * */
public double getFillingPrice() {
    return fillingPrice;
}

    /**
     * @param string the name of the filling
     * @author Miyake,Zohra
     * */
public String getFillingName() {
    return fillingName;
}

    }

