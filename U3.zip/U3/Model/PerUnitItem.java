package Model;
/*
        Represents a unit item the items other than Cake that is sold

        Gets  name, price and is also able to write these as strings
 */
public class PerUnitItem extends MenuItem {
    private double unitPrice;


    /**
     *
     *    @param Name of unit item, price
     *    @author Miyake, Zohra
     */
    public PerUnitItem(String name,double unitPrice) {
        super(name);
        this.unitPrice = unitPrice;
    }
    /**
     *
     *    @return price of the item as a double
     *    @author Miyake, Zohra
     */
    public double getPrice() {
        return unitPrice;
    }

    /**
     *
     *    @return Name of unit item, price as a string
     *    @author Miyake, Zohra
     */
    @Override
    public String toString() {
        return "Name :" + super.getName() + "   Price:" +  unitPrice;
    }
}
