package Model;

import java.util.ArrayList;

/**
    Represents the order so the items in each order
    it gets an arrauList of itmes gives each order an id, calculates the orders price
    and writes the order as a string in an array and a string from the toString method
*/

public class Order {
    private int id = 0;
    static private int nextId = 1;
    private ArrayList<MenuItem> items;

    /**
     *
     *    @param items as an array list of MenuItems
     *    @author Miyake, Zohra
     */
    public Order(ArrayList<MenuItem> items) {
        this.items = items;
        id = nextId++;
    }

    /**
     *
     *    @return order id as an int;
     *    @author Miyake, Zohra
     */

    public int getId() {
        return id;
    }

    /**
     *
     *    @return items as an array list of MenuItems
     *    @author Miyake, Zohra
     */
    public ArrayList<MenuItem> getItems() {
    return items;
    }

    /**
     *
     *    @return String of items
     *    @author Miyake, Zohra
     */

    public String[] getItemsAsStringArray() {
        String[] arr = new String[items.size()];
        for (int i = 0; i < items.size(); i++) {
            arr[i] = items.get(i).toString();
        }
        return arr;
    }

    /**
     *
     *    @return a double total cost of all the items in the order
     *    @author Miyake, Zohra
     */
    public double getTotalCost() {
        double total = 0;
        for (MenuItem item : items) {
            total += item.getPrice();
        }
        return total;
    }
    /**
     *
     *    @return returns a string of the order id, cost and items
     *    @author Miyake, Zohra
     */
    @Override
    public String toString() {
        return "Order ID: " + id + "  Total Cost: " + getTotalCost() + items.toString() + " "  ;
    }
}
