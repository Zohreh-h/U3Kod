package Model;

/**
 * Is an abstract class that represents all of the menu items it chooses their name
 *  It lets the other classes implement getPrice and the toString method
 */

public abstract class MenuItem {
    private String name;

    /**
     *
     *    @param name of the item, Cake/PerUnitItem
     *    @author Miyake, Zohra
     */
    public MenuItem(String name) {
        this.name = name;
    }
    /**
     *
     *    @return Name of the item as a String
     *    @author Miyake, Zohra
     */
    public String getName() {
        return name;
    }
    /**
     *
     *    @return price as a double that is implemented in its subclasses Cake and PerUnitItem
     *    @author Miyake, Zohra
     */
    public abstract double getPrice();
    /**
     *
     *    @return Items toString, returns a string implemented in the subclasses
     *    @author Miyake, Zohra
     */
    @Override
    public abstract String toString();
}
