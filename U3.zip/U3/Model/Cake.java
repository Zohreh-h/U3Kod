package Model;

import java.util.Arrays;


/**
 * Represents a cake with a name, fillings and size in slices.
 * Can calculate its price and return a string representation.
 *
 * @author Miyake, Zohra
 */

public class Cake extends MenuItem {
    private int sizeInSlices;
    private Filling[] fillings;
    private double basePrice = 10;
/**
*
*    @param name of cake, fillings the cakes filling, the size in slices
*    @author Miyake, Zohra
 */
    public Cake(String name, Filling[] fillings, int sizeInSlices) {
        super(name);
        this.sizeInSlices = sizeInSlices;
        this.fillings = fillings;

    }

    /**
     *
     *    @author Miyake, Zhora
     *    @return The cakes calculated price as double is returned
     */
    public double calculatePrice() {
        double fillingsPrice = 0;
        for (int i = 0; i<fillings.length; i++) {
            fillingsPrice += fillings[i].getFillingPrice();
        }
        return (basePrice*sizeInSlices)+ fillingsPrice;
    }

    /**
     *
     *
     *    @author Miyake, Zohra
     *    @return The Cake price as a double
     */
    public double getPrice() {
        return calculatePrice();
    }

    /**
     *
     *    @author Miyake, Zohra
     *    @return String of the Cake name, fillings and price
     */
    @Override
    public String toString() {
        String fillingsString ="";
        for(int i = 0; i < fillings.length; i++){
            fillingsString += fillings[i].toString() + ": ";
        }
        return "Name: "+ super.getName()+  " fyllning: " + fillingsString + " size: " +sizeInSlices +" cost: " + calculatePrice();


    }
}
