package controller;

//only imports what is strictly necessary from view-package
import Model.Cake;
import Model.Filling;
import Model.MenuItem;
import Model.PerUnitItem;
import Model.*;
import view.CustomCakeFrame;
import view.MainFrame;
import view.ButtonType;

import javax.swing.*;
import java.util.ArrayList;

public class Controller {
    private MainFrame view;
    private CustomCakeFrame newCakeType;
    private MenuItem[] items;
    private ButtonType currentLeftMenu = ButtonType.NoChoice;


    String[] cakeMenuString = new String[5];
    String[] perUnitItemMenuString = new String[7];
    private ArrayList<String> currentOrderList = new ArrayList<>();
    private double costCurrentOrder = 0; // for test purposes only
    private ArrayList<MenuItem> currentOrderItems = new ArrayList<>();
    private ArrayList<Order> orderHistory = new ArrayList<>();


    public Controller() {
        view = new MainFrame(1000, 500, this);
        loadStringTestValues(); //for test purposes - remove when not needed more
        view.enableAllButtons();
        view.disableAddMenuButton();
        view.disableViewSelectedOrderButton();
    }

    //This method is only used for test purposes - remove when no longer needed
    private void loadStringTestValues() {

        items = new MenuItem[6];
        items[0] = new Cake("Princesstårta", new Filling[] {Filling.VANILJ,Filling.GRÄDDE}, 4);
        items[1] = new Cake("Budapest", new Filling[] {Filling.FRUKT,Filling.CHOCKLAD}, 6);
        items[2] = new Cake("Morotstårta", new Filling[] {Filling.GLASS,Filling.GRÄDDE}, 8);
        items[3] = new PerUnitItem("Bulle",10);
        items[4] = new PerUnitItem("Doughnut",20);
        items[5] = new PerUnitItem("Kaffe",25);

    }

    //This method is called by class MinFrame when a button in teh GUI is pressed
    public void buttonPressed(ButtonType button){

        switch (button) {
            case Add:
                addItemToOrder(view.getSelectionLeftPanel());
                break;

            case Cake:
                setToCakeMenu();
                break;

            case PerUnitItem:
                setToPerUnitItemMenu();
                break;

            case MakeCake:
                addNewCake();
                break;

            case OrderHistory:
                setToOrderHistoryMenu();
                break;

            case Order:
                placeOrder();
                break;

            case ViewOrder:
                viewSelectedOrder(view.getSelectionLeftPanel());
                break;
        }
    }

    public void addItemToOrder(int selectionIndex) {
        System.out.println("Index selection left panel: " + selectionIndex); //for test purposes  - remove when not needed

        if (selectionIndex != -1){ // if something is selected in the left menu list
            MenuItem selectedItem = items[selectionIndex];
            currentOrderItems.add(selectedItem);

            //currentOrderArray[nbrOfOrders] = selectedItem.toString();

            costCurrentOrder += items[selectionIndex].getPrice();


            switch (currentLeftMenu) { //This might need to change depending on architecture
                case Cake:
                    //currentOrderArray[nbrOfOrders] = items[selectionIndex].toString(); //for test purposes - needs to be replaced with solution of finding chosen menu item matching architecture for model
                    currentOrderList.add(items[selectionIndex].toString());
                    break;
                case PerUnitItem:
                    //currentOrderArray[nbrOfOrders] = items[selectionIndex].toString(); //see comment for case above
                    currentOrderList.add(items[selectionIndex].toString());
                    break;
            }

            view.populateRightPanel(currentOrderList.toArray(new String[currentOrderList.size()]));
            view.setTextCostLabelRightPanel("Total cost of order: " + String.valueOf(costCurrentOrder)); //set the text to show cost of current order
        }

    }



    public void viewSelectedOrder(int selectionIndex){
       /* System.out.println("Index selection left panel: " + selectionIndex); //for test purposes  - remove when not needed
        String[] historyString = new String[orderHistory.size()];
        for (int i = 0; i < orderHistory.size(); i++) {
            historyString[i] =orderHistory.get(i).toString();
        }*/




        if ((selectionIndex != -1) && currentLeftMenu==ButtonType.OrderHistory){
            Order selectedOrder = orderHistory.get(selectionIndex);

            String[] orderItems = selectedOrder.getItemsAsStringArray();
            costCurrentOrder = selectedOrder.getTotalCost(); //for test purposes - replace with calculation of cost when how orders are handled is implemented in model
            view.populateRightPanel(selectedOrder.getItemsAsStringArray());//update left panel with order details - this takes a shortcut in updating the entire information in the panel not just adds to the end
            view.setTextCostLabelRightPanel("Total cost of order: " + String.valueOf(costCurrentOrder)); //set the text to show cost of current order
        }
    }


    public void setToCakeMenu() {

        for (int i=0; i<items.length; i++){
            if(items[i] instanceof Cake){
                cakeMenuString[i] = items[i].toString();
            }

        }

        currentLeftMenu = ButtonType.Cake;
        view.populateLeftPanel(cakeMenuString);
        view.populateRightPanel(currentOrderList.toArray(new String[0])); //update left panel with new item - this takes a shortcut in updating the entire information in the panel not just adds to the end
        view.setTextCostLabelRightPanel("Total cost of order: " + String.valueOf(costCurrentOrder)); //set the text to show cost of current order
        view.enableAllButtons();
        view.disableCakeMenuButton();
        view.disableViewSelectedOrderButton();
    }


    public void setToPerUnitItemMenu() {

        for (int i=0; i<items.length; i++){
            if(items[i] instanceof PerUnitItem){
                perUnitItemMenuString[i] = items[i].toString();
            }
        }

        currentLeftMenu = ButtonType.PerUnitItem;
        view.populateLeftPanel(perUnitItemMenuString);
        //Here below updated and in setCakeToMenu
        view.populateRightPanel(currentOrderList.toArray(new String[0])); //update left panel with new item - this takes a shortcut in updating the entire information in the panel not just adds to the end
        view.setTextCostLabelRightPanel("Total cost of order: " + String.valueOf(costCurrentOrder)); //set the text to show cost of current order
        view.enableAllButtons();
        view.disablePerUnitItemMenuButton();
        view.disableViewSelectedOrderButton();
    }

    public void setToOrderHistoryMenu() {
        String[] historyStrings = new String[orderHistory.size()];
        for (int i=0; i<orderHistory.size(); i++){
            historyStrings[i] = orderHistory.get(i).toString();
        }
        currentLeftMenu = ButtonType.OrderHistory;
        view.clearRightPanel();
        view.populateLeftPanel(historyStrings);
        view.enableAllButtons();
        view.disableAddMenuButton();
        view.disableOrderButton();
    }


    public void addNewCake() {
        newCakeType = new CustomCakeFrame(this);
        //For grade VG: Add more code to save the new cake type and update menu.
        view.enableAllButtons();
    }

    public void placeOrder() {
        if (currentOrderItems.isEmpty()){
            JOptionPane.showMessageDialog(null,"The Order is empty");
            return;
        }
        System.out.println("Pressed Order to create a new order"); //for test purposes - remove when not needed more
        Order newOrder = new Order(new ArrayList<>(currentOrderItems));

        orderHistory.add(newOrder);

        currentOrderItems.clear();
        currentOrderList.clear();



        costCurrentOrder = 0;
        view.clearRightPanel(); //Removes information from right panel in GUI
        view.setTextCostLabelRightPanel("TOTAL COST: 0");
        view.enableAllButtons();
        view.disableAddMenuButton();
        view.disableViewSelectedOrderButton();
    }


}
